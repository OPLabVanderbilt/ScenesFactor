library(psych)

# Read data
df <- read.csv("Data_Artist_pilot2_35_accuracy.csv")

# Extract tasks by column name patterns
artist_cols <- grep("^Accurate\\.(9|[1-4][0-9]|5[0-5])$", colnames(df))
scene_cols <- grep("^Accurate\\.(6[0-9]|7[0-9]|8[0-4])$", colnames(df))

artist_data <- df[, artist_cols]
scene_data <- df[, scene_cols]

# Calculate scene mean for each participant
scene_mean <- rowMeans(scene_data, na.rm = TRUE)

# Initialize results dataframe
trial_numbers <- as.numeric(gsub("Accurate\\.", "", colnames(artist_data)))
results <- data.frame(
  trial = trial_numbers,
  mean_acc = numeric(length(artist_cols)),
  cor_with_rest = numeric(length(artist_cols)),
  cor_with_scene = numeric(length(artist_cols))
)

# Calculate metrics for each Artist trial
for (i in seq_along(artist_cols)) {
  trial_data <- artist_data[, i]
  rest_data <- artist_data[, -i]
  rest_mean <- rowMeans(rest_data, na.rm = TRUE)
  
  results$mean_acc[i] <- mean(trial_data, na.rm = TRUE)
  results$cor_with_rest[i] <- cor(trial_data, rest_mean, use = "complete.obs")
  results$cor_with_scene[i] <- cor(trial_data, scene_mean, use = "complete.obs")
}

# Calculate Cronbach's alpha without reversing items
alpha_result <- suppressWarnings(alpha(artist_data, check.keys = FALSE))
overall_alpha <- alpha_result$total$raw_alpha

# Add alpha to results
results$overall_alpha <- overall_alpha

# Save results
write.csv(results, "artist_trial_analysis.csv", row.names = FALSE)

cat("Overall Cronbach's Alpha:", round(overall_alpha, 3), "\n")